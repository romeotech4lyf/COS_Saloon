package com.tech4lyf.cossaloon;

public final class Context {
    //public enum DASHBOARD_ITEM { STORES,EMPLOYEES,SERVICES,AREAS }
    public  enum OBJECT_TYPE { STORE,EMPLOYEE,SERVICE,AREA,NULL}

    public enum FLAG{ADD,UPDATE,CANCEL,DELETE}
}
